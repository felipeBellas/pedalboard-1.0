const P=[
 {n:"OVERDRIVE",ic:"🔥",c:"#6bbf59",k:["drive","tom","nível"],d:[.4,.5,.5]},
 {n:"TREMOLO",ic:"〰️",c:"#d4a72c",k:["velocidade","profundidade"],d:[.4,.5]},
 {n:"DELAY",ic:"⏱️",c:"#4a90d9",k:["tempo","repetições","mix"],d:[.4,.35,.3]}
];
const A=window.Android,E=(t,c)=>Object.assign(document.createElement(t),{className:c||""});
let S;try{S=JSON.parse(localStorage.s)}catch(e){}
S=S&&S.v?S:{on:P.map(()=>0),v:P.map(p=>[...p.d])};
const save=()=>{try{localStorage.s=JSON.stringify(S)}catch(e){}};
const board=document.getElementById("board"),bar=document.getElementById("bar");

P.forEach((p,i)=>{
  const s=E("section","slide"),d=E("div","pedal"),led=E("div","led"),nm=E("div","name"),kn=E("div","knobs");
  d.style.setProperty("--c",p.c);nm.textContent=p.n;
  p.k.forEach((label,j)=>{
    const k=E("div","knob"),r=E("i");k.append(r,label);
    const draw=()=>r.style.setProperty("--a",(S.v[i][j]*270-135)+"deg");
    draw();A&&A.param(i,j,S.v[i][j]);
    let y=null,v0=0;
    k.onpointerdown=e=>{k.setPointerCapture(e.pointerId);y=e.clientY;v0=S.v[i][j]};
    k.onpointermove=e=>{if(y===null)return;const v=Math.min(1,Math.max(0,v0+(y-e.clientY)/150));S.v[i][j]=v;draw();A&&A.param(i,j,v)};
    k.onpointerup=k.onpointercancel=()=>{y=null;save()};
    kn.append(k);
  });
  const f=E("button","foot"),b=E("button");
  b.textContent=p.ic;b.style.setProperty("--c",p.c);
  const set=o=>{S.on[i]=o?1:0;d.classList.toggle("on",!!o);b.classList.toggle("on",!!o);A&&A.on(i,!!o);save()};
  f.onclick=()=>set(!S.on[i]);
  b.onclick=()=>s.scrollIntoView({behavior:"smooth",inline:"center"});
  d.append(led,nm,kn,f);s.append(d);board.append(s);bar.append(b);set(S.on[i]);
});

const bs=[...bar.children],io=new IntersectionObserver(es=>es.forEach(e=>{
  if(e.isIntersecting)bs.forEach((x,n)=>x.classList.toggle("cur",board.children[n]===e.target))
}),{root:board,threshold:.6});
[...board.children].forEach(c=>io.observe(c));
