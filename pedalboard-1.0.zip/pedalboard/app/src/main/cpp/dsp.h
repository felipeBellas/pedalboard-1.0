// Cadeia de pedais: Overdrive -> Tremolo -> Delay. Sem alocação nem locks no callback.
// Pedal desligado = zero custo (o bloco é pulado).
#pragma once
#include <atomic>
#include <cmath>
#include <cstdint>
#include <vector>

struct Pedal {
    std::atomic<bool> on{false};
    std::atomic<float> p[3];  // parâmetros normalizados 0..1
    Pedal() { for (auto& x : p) x.store(0.5f); }
};

class Chain {
public:
    Pedal ped[3];

    void prepare(float sr) {  // chamado fora da thread de áudio
        sr_ = sr;
        dly_.assign(static_cast<size_t>(sr) + 1, 0.f);
        w_ = 0; lp_ = 0; ph_ = 0;
    }

    void process(float* x, int n) {
        const bool od = ped[0].on, tr = ped[1].on, dl = ped[2].on;
        if (!(od || tr || dl)) return;  // tudo desligado: passa direto
        noDenormals();
        const float drive = 1.f + ped[0].p[0] * 40.f;
        const float a = 0.02f + ped[0].p[1] * 0.6f;  // filtro de tom (passa-baixa)
        const float lvl = ped[0].p[2] * 1.5f;
        const float rate = (0.5f + ped[1].p[0] * 9.f) / sr_, depth = ped[1].p[1];
        const float fb = ped[2].p[1] * 0.85f, mix = ped[2].p[2];
        const int len = static_cast<int>(dly_.size());
        const int dt = static_cast<int>((0.05f + ped[2].p[0] * 0.75f) * sr_);

        for (int i = 0; i < n; ++i) {
            float s = x[i];
            if (od) {
                float v = s * drive;
                v = v > 3.f ? 3.f : (v < -3.f ? -3.f : v);
                v = v * (27.f + v * v) / (27.f + 9.f * v * v);  // tanh racional
                lp_ += a * (v - lp_);
                s = lp_ * lvl;
            }
            if (tr) {
                ph_ += rate; if (ph_ >= 1.f) ph_ -= 1.f;
                float tri = std::fabs(2.f * ph_ - 1.f);  // LFO triangular, mais barato que sin()
                s *= 1.f - depth * tri;
            }
            if (dl) {
                int r = w_ - dt; if (r < 0) r += len;
                float d = dly_[r];
                dly_[w_] = s + d * fb;
                if (++w_ == len) w_ = 0;
                s += d * mix;
            }
            x[i] = s;
        }
    }

private:
    static inline void noDenormals() {
#if defined(__aarch64__)
        uint64_t f; asm volatile("mrs %0, fpcr" : "=r"(f));
        f |= (1ull << 24);  // flush-to-zero
        asm volatile("msr fpcr, %0" :: "r"(f));
#endif
    }
    float sr_ = 48000.f, lp_ = 0.f, ph_ = 0.f;
    std::vector<float> dly_;
    int w_ = 0;
};
