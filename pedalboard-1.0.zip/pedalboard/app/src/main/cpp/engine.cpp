#include <jni.h>
#include <oboe/Oboe.h>
#include <algorithm>
#include <memory>
#include "dsp.h"

static Chain chain;
static std::shared_ptr<oboe::AudioStream> in, out;

class Callback : public oboe::AudioStreamDataCallback {
public:
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t n) override {
        auto* o = static_cast<float*>(data);
        auto r = in->read(o, n, 0);  // leitura sem bloqueio
        int got = r ? r.value() : 0;
        std::fill(o + got, o + n, 0.f);
        chain.process(o, n);
        return oboe::DataCallbackResult::Continue;
    }
};
static Callback cb;

extern "C" {
JNIEXPORT void JNICALL Java_app_pedalboard_Native_start(JNIEnv*, jobject) {
    if (out) return;
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Input)->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Mono)->setInputPreset(oboe::InputPreset::Unprocessed);
    if (b.openStream(in) != oboe::Result::OK) { in.reset(); return; }
    chain.prepare(static_cast<float>(in->getSampleRate()));
    b.setDirection(oboe::Direction::Output)->setSampleRate(in->getSampleRate())
        ->setDataCallback(&cb)->setUsage(oboe::Usage::Media);
    if (b.openStream(out) != oboe::Result::OK) { in->close(); in.reset(); out.reset(); return; }
    out->setBufferSizeInFrames(out->getFramesPerBurst() * 2);  // equilíbrio latência x CPU
    in->requestStart(); out->requestStart();
}
JNIEXPORT void JNICALL Java_app_pedalboard_Native_stop(JNIEnv*, jobject) {
    if (out) { out->stop(); out->close(); out.reset(); }
    if (in) { in->stop(); in->close(); in.reset(); }
}
JNIEXPORT void JNICALL Java_app_pedalboard_Native_setOn(JNIEnv*, jobject, jint id, jboolean on) {
    if (id >= 0 && id < 3) chain.ped[id].on.store(on);
}
JNIEXPORT void JNICALL Java_app_pedalboard_Native_setParam(JNIEnv*, jobject, jint id, jint i, jfloat v) {
    if (id >= 0 && id < 3 && i >= 0 && i < 3) chain.ped[id].p[i].store(std::clamp(v, 0.f, 1.f));
}
}
