package app.pedalboard

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {
    private fun granted() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    class Bridge {
        @JavascriptInterface fun on(id: Int, v: Boolean) = Native.setOn(id, v)
        @JavascriptInterface fun param(id: Int, i: Int, v: Float) = Native.setParam(id, i, v)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(0xFF121212.toInt())
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/ui/index.html")
        }
        setContentView(web)
        if (!granted()) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    // O áudio só roda com o app visível: economiza bateria (serviço em primeiro plano fica para a 1.1).
    override fun onStart() { super.onStart(); if (granted()) Native.start() }
    override fun onStop() { super.onStop(); Native.stop() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (granted()) Native.start()
    }
}
