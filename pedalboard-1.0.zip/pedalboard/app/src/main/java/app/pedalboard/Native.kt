package app.pedalboard

object Native {
    init { System.loadLibrary("pedalboard") }
    external fun start()
    external fun stop()
    external fun setOn(id: Int, on: Boolean)
    external fun setParam(id: Int, index: Int, value: Float)
}
